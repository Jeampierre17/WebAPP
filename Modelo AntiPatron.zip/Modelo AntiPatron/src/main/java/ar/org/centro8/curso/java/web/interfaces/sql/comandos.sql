use negocioWeb;
select * from articulos;




