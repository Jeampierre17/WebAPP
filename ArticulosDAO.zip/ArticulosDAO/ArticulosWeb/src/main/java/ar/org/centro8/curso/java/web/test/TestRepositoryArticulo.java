package ar.org.centro8.curso.java.web.test;

import ar.org.centro8.curso.java.web.entities.Articulo;
import ar.org.centro8.curso.java.web.enums.EspecieRecomendada;
import ar.org.centro8.curso.java.web.enums.TipoArticulo;
import ar.org.centro8.curso.java.web.interfaces.connectors.Connector;
import ar.org.centro8.curso.java.web.repositories.interfaces.I_ArticuloRepository;
import ar.org.centro8.curso.java.web.repositories.jdbc.ArticuloRepository;


public class TestRepositoryArticulo {
	 public static void main(String[] args) {
	       
	        I_ArticuloRepository ar=new ArticuloRepository(Connector.getConnection());
	        
//	    	ar.save(new Articulo("Pelota", "pelota", TipoArticulo.JUGUETE, EspecieRecomendada.CANINO, 10, 17, 50, 10, 100, "", true));
//			ar.save(new Articulo( "Rascador", "cartón", TipoArticulo.ACCESORIO, EspecieRecomendada.FELINO, 20.5, 40, 20, 5, 50, "", true));
//			ar.save(new Articulo( "Piedritas", "piedra", TipoArticulo.ACCESORIO, EspecieRecomendada.FELINO, 8, 15, 35, 10, 70, "", true));
//			ar.save(new Articulo( "Correa", "tela", TipoArticulo.ACCESORIO, EspecieRecomendada.CANINO, 12, 20, 15, 3, 30, "", true));
//			
	        ar.getAll().forEach(System.out::println);
	        System.out.println("****************************************************");
	        ar.getLikeNombre("bola").forEach(System.out::println);
	        System.out.println("****************************************************");
	        
	    }
	}
