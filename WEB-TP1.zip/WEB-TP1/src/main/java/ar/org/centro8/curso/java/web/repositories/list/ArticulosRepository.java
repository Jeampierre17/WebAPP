package ar.org.centro8.curso.java.web.repositories.list;

import java.util.ArrayList;
import java.util.List;

import ar.org.centro8.curso.java.web.entities.Articulos;
import ar.org.centro8.curso.java.web.repositories.interfaces.I_ArticulosRepository;


public class ArticulosRepository implements I_ArticulosRepository {
	
	 private List<Articulos>list=new ArrayList();

	    @Override
	    public void save(Articulos articulos) {
	        list.add(articulos);
	    }

	    
		@Override
	    public void remove(Articulos articulos) {
	        list.remove(articulos);
	    }

	    @Override
	    public void update(Articulos articulos) {
	        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
	    }

	    @Override
	    public List<Articulos> getAll() {
	        return list;
	    }
}
