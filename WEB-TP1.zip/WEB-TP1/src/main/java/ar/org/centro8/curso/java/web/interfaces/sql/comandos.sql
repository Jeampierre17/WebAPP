use negocioWeb;
/*select * from direcciones;
select * from clientes;*/
select * from articulos;
show tables;
/*select * from V_clientes_direcciones;*/

