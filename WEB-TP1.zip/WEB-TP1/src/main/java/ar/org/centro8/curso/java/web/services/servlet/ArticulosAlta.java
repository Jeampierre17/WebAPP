package ar.org.centro8.curso.java.web.services.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ar.org.centro8.curso.java.web.entities.Articulos;
import ar.org.centro8.curso.java.web.enums.EspecieRecomendada;
import ar.org.centro8.curso.java.web.enums.TipoArticulo;
import ar.org.centro8.curso.java.web.repositories.interfaces.I_ArticulosRepository;
import ar.org.centro8.curso.java.web.repositories.list.ArticulosRepositoryFactory;

/**
 * Servlet implementation class ArticulosAlta
 */
@WebServlet("/ArticulosAlta")
public class ArticulosAlta extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        I_ArticulosRepository ar=ArticulosRepositoryFactory.getArticulosRepository();
        response.setContentType("text/plain;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {System.out.println("prueba");
            try {
                //Articulos
                String nombre=request.getParameter("nombre");
                String descripcion=request.getParameter("descripcion");
                TipoArticulo tipo=TipoArticulo.valueOf(request.getParameter("tipo"));
                EspecieRecomendada especieRecomendada=EspecieRecomendada.valueOf(request.getParameter("especieRecomendada"));
                double costo =  Double.parseDouble(request.getParameter("costo"));
                double precio=Double.parseDouble(request.getParameter("precio"));
                int stock=Integer.parseInt(request.getParameter("stock"));
                int stockMinimo=Integer.parseInt(request.getParameter("stockMinimo"));
                int stockMaximo=Integer.parseInt(request.getParameter("stockMaximo"));
                String comentarios=request.getParameter("comentarios");
                boolean activo= Boolean.valueOf(request.getParameter("activo"));
                
                
                
                Articulos articulos= new Articulos(nombre, descripcion, tipo, especieRecomendada, costo, precio, stock, stockMinimo, stockMaximo, comentarios, activo);
                
       
    
                
                ar.save(articulos);
                out.println(articulos.getId());
                
                //http://localhost:8090/Clase04/ArticulosAltas?nombre=Pelota&descripcion=pelota&tipo=JUGUETE&especieRecomendada=CANINO&costo=10&precio=17&stock=50&stockMinimo=10&stockMaximo=100&comentarios=x&activo=true
                //http://localhost:8090/Clase04/ArticulosAltas?nombre=Almuadón&descripcion=pelota&tipo=JUGUETE&especieRecomendada=CANINO&costo=10&precio=17&stock=50&stockMinimo=10&stockMaximo=100&comentarios=x&activo=true
                //http://localhost:8090/Clase04/ArticulosAltas?nombre=Correa&descripcion=pelota&tipo=JUGUETE&especieRecomendada=CANINO&costo=10&precio=17&stock=50&stockMinimo=10&stockMaximo=100&comentarios=x&activo=true
                //http://localhost:8090/Clase04/ArticulosAltas?nombre=Peluche&descripcion=pelota&tipo=JUGUETE&especieRecomendada=CANINO&costo=10&precio=17&stock=50&stockMinimo=10&stockMaximo=100&comentarios=x&activo=true
                
            } catch (Exception e) {
                out.println("error");
                System.out.println(e);
            }
                  
        }
    }
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}
	
	  @Override
	    public String getServletInfo() {
	        return "Short description";
	    }// </editor-fold>


}
