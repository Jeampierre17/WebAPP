package ar.org.centro8.curso.java.web.repositories.list;

public class ArticulosRepositoryFactory {
	  private static ArticulosRepository cr=new ArticulosRepository();
	    private ArticulosRepositoryFactory(){}
	    public static ArticulosRepository getArticulosRepository(){
	        return cr;
	    }

}
