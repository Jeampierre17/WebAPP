package ar.org.centro8.curso.java.web.repositories.interfaces;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import ar.org.centro8.curso.java.web.entities.Articulos;
import ar.org.centro8.curso.java.web.enums.EspecieRecomendada;
import ar.org.centro8.curso.java.web.enums.TipoArticulo;

public interface I_ArticulosRepository {
	  void save(Articulos articulos);
	    void remove(Articulos articulos);
	    void update(Articulos articulos);
	    default Articulos getById(int id){
	        return getAll()
	                .stream()
	                .filter(c->c.getId()==id)
	                .findFirst()
	                .orElse(new Articulos());
	    }
	    
	    List<Articulos>getAll();
	    
	    default List<Articulos>getLikeNombre(String nombre){
	        if(nombre==null) return new ArrayList<Articulos>();
	        return getAll()
	                .stream()
	                .filter(c->c.getNombre()!=null 
	                        && c.getNombre().toLowerCase().contains(nombre.toLowerCase()))
	                .collect(Collectors.toList());
	    }
	    
	    default Articulos getByTipoArticulo(TipoArticulo tipo){
	        if(tipo==null) return new Articulos();
	        return getAll()
	                .stream()
	                .filter(c->c.getTipo()!=null  
	                        && c.getTipo()==tipo)
	                .findAny()
	                .orElse(new Articulos());
	    }
	

	    default Articulos getByEspecieRecomendada(EspecieRecomendada tipo){
	    	if(tipo==null ) return new Articulos();
	    	return getAll()
            .stream()
            .filter(c->c.getTipo()!=null)
            .findAny()
            .orElse(new Articulos());
}
}

