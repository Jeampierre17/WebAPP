package ar.org.centro8.curso.java.web.interfaces.test;

import ar.org.centro8.curso.java.web.entities.Articulos;
import ar.org.centro8.curso.java.web.enums.EspecieRecomendada;
import ar.org.centro8.curso.java.web.enums.TipoArticulo;
import ar.org.centro8.curso.java.web.repositories.interfaces.I_ArticulosRepository;
import ar.org.centro8.curso.java.web.repositories.list.ArticulosRepositoryFactory;

public class TestArticulosRepository {
	public static void main(String[] args) {
		I_ArticulosRepository ar= ArticulosRepositoryFactory.getArticulosRepository();
		ar.save(new Articulos("Pelota", "pelota", TipoArticulo.JUGUETE, EspecieRecomendada.CANINO, 10, 17, 50, 10, 100, "", true));
		ar.save(new Articulos( "Rascador", "cartón", TipoArticulo.ACCESORIO, EspecieRecomendada.FELINO, 20.5, 40, 20, 5, 50, "", true));
		ar.save(new Articulos( "Piedritas", "piedra", TipoArticulo.ACCESORIO, EspecieRecomendada.FELINO, 8, 15, 35, 10, 70, "", true));
		ar.save(new Articulos( "Correa", "tela", TipoArticulo.ACCESORIO, EspecieRecomendada.CANINO, 12, 20, 15, 3, 30, "", true));
		
		ar.getAll().forEach(System.out::println);
		 System.out.println("****************************************************");
	        ar.getLikeNombre("p").forEach(System.out::println);
	        System.out.println("****************************************************");
	}

}
