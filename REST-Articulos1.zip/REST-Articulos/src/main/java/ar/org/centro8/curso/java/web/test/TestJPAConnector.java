package ar.org.centro8.curso.java.web.test;

import ar.org.centro8.curso.java.web.entities.Cliente;
import ar.org.centro8.curso.java.web.entities.Direccion;
import ar.org.centro8.curso.java.web.enums.TipoDocumento;
import java.time.LocalTime;
import java.util.Date;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class TestJPAConnector {
    public static void main(String[] args) {
        tiempo();
        EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPAPU");
        tiempo();
        EntityManager em=emf.createEntityManager();
        tiempo();
        
        Query query=em.createNamedQuery("Direccion.findById");
        query.setParameter("id", 1);
        Direccion dir=(Direccion)query.getSingleResult();
        Cliente cliente=new Cliente("Juan", "Bautista", new Date(1980, 10, 10), TipoDocumento.DNI.toString(), "98939393", "239939494", "nada@nada.com", "", dir);
        Cliente cliente2=new Cliente("Ramiro", "Basualdo", new Date(1980, 10, 11), TipoDocumento.DNI.toString(), "98939394", "239939494", "nada@nada.com", "", dir);
        
        Query query2=em.createNamedQuery("Cliente.findById");
        query2.setParameter("id", 4);
        //Cliente clientex=(Cliente)query2.getSingleResult();
        /*
        EntityTransaction tr=em.getTransaction();
        tr.begin();
        try{
            em.persist(cliente);
            em.persist(cliente2);
            //em.remove(clientex);
            tr.commit();
            System.out.println("Se guardo!");
        }catch(javax.persistence.PersistenceException e){
            System.out.println("Error "+e.getLocalizedMessage());
            System.out.println("Error "+e.getMessage());
            tr.rollback();
        }catch(Exception e){
            System.out.println(e);
            tr.rollback();
        }
        */
    
        
        //em.createNamedQuery("Cliente.findAll").getResultList().forEach(System.out::println);
        
        tiempo();
        
        //em.createNamedQuery("Direccion.findAll").getResultList().forEach(System.out::println);
        
        Query query3=em.createNamedQuery("Cliente.findLikeApellido");
        query3.setParameter("apellido", "%ba%");
        query3.getResultList().forEach(System.out::println);
        
        tiempo();
        em.close();
        tiempo();
        emf.close();
        tiempo();
    }

    private static void tiempo() {
        System.out.println("******************************************");
        System.out.println(LocalTime.now());
        System.out.println("******************************************");
    }
}
