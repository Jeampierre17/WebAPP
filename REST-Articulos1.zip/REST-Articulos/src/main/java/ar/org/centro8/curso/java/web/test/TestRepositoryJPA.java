package ar.org.centro8.curso.java.web.test;

import ar.org.centro8.curso.java.web.entities.Cliente;
import ar.org.centro8.curso.java.web.entities.Direccion;
import ar.org.centro8.curso.java.web.enums.TipoDocumento;
import ar.org.centro8.curso.java.web.repositories.interfaces.I_ClienteRepository;
import ar.org.centro8.curso.java.web.repositories.jpa.ClienteRepository;
import java.util.Date;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class TestRepositoryJPA {
    public static void main(String[] args) {
        EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPAPU");
        I_ClienteRepository cr=new ClienteRepository(emf);
        EntityManager em=emf.createEntityManager();

        Direccion dir=new Direccion("Lima", 22, null, null, null, "1712", "CABA", "CABA", "ARGENTINA");
        Cliente cliente=new Cliente(
                                        "Rosa", 
                                        "Nomales", 
                                        new Date(1980, 10, 10), 
                                        TipoDocumento.DNI.toString(), 
                                        "12341268", 
                                        "111111", 
                                        "nada@nada.com",
                                        "nada", 
                                        dir
        );
        //cr.save(cliente);
        System.out.println(cliente);
        
        //System.out.println(cr.getById(7));
        cr.remove(cr.getById(1));
        
        System.out.println("****************************************************");
        cr.getAll().forEach(System.out::println);
        System.out.println("****************************************************");
        cr.getLikeApellido("ri").forEach(System.out::println);
    }
}
