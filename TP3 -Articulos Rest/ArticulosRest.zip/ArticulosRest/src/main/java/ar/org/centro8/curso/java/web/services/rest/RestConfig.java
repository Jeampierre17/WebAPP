package ar.org.centro8.curso.java.web.services.rest;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/web")
public class RestConfig extends Application{
    
}
