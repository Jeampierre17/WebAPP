package ar.org.centro8.curso.java.web.services.servlet;

import ar.org.centro8.curso.java.web.entities.Articulo;
import ar.org.centro8.curso.java.web.enums.EspecieRecomendada;
import ar.org.centro8.curso.java.web.enums.TipoArticulo;
import ar.org.centro8.curso.java.web.interfaces.connectors.Connector;

import ar.org.centro8.curso.java.web.repositories.interfaces.I_ArticuloRepository;
import ar.org.centro8.curso.java.web.repositories.jdbc.ArticuloRepository;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/ArticuloAlta")
public class ArticuloAlta extends HttpServlet {

	protected void processRequest(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		I_ArticuloRepository ar=new ArticuloRepository(Connector.getConnection());
		response.setContentType("text/plain;charset=UTF-8");
		try (PrintWriter out = response.getWriter()) {
			try {
				//Articulos
				String nombre=request.getParameter("nombre");
				String descripcion=request.getParameter("descripcion");
				TipoArticulo tipo=TipoArticulo.valueOf(request.getParameter("tipo"));
				EspecieRecomendada especieRecomendada=EspecieRecomendada.valueOf(request.getParameter("especieRecomendada"));
				double costo =  Double.parseDouble(request.getParameter("costo"));
				double precio=Double.parseDouble(request.getParameter("precio"));
				int stock=Integer.parseInt(request.getParameter("stock"));
				int stockMinimo=Integer.parseInt(request.getParameter("stockMinimo"));
				int stockMaximo=Integer.parseInt(request.getParameter("stockMaximo"));
				String comentarios=request.getParameter("comentarios");
				boolean activo= Boolean.valueOf(request.getParameter("activo"));



				Articulo articulo= new Articulo(nombre, descripcion, tipo, especieRecomendada, costo, precio, stock, stockMinimo, stockMaximo, comentarios, activo);




				ar.save(articulo);
				out.println(articulo.getId());

				//http://localhost:8090/server/ArticuloAlta?nombre=Pelota&descripcion=pelota&tipo=JUGUETE&especieRecomendada=CANINO&costo=10&precio=17&stock=50&stockMinimo=10&stockMaximo=100&comentarios=x&activo=true
				//http://localhost:8090/server/ArticuloAlta?nombre=Almuadón&descripcion=pelota&tipo=JUGUETE&especieRecomendada=CANINO&costo=10&precio=17&stock=50&stockMinimo=10&stockMaximo=100&comentarios=x&activo=true
				//http://localhost:8090/server/ArticuloAlta?nombre=Correa&descripcion=pelota&tipo=JUGUETE&especieRecomendada=CANINO&costo=10&precio=17&stock=50&stockMinimo=10&stockMaximo=100&comentarios=x&activo=true
				//http://localhost:8090/server/ArticuloAlta?nombre=Peluche&descripcion=pelota&tipo=JUGUETE&especieRecomendada=CANINO&costo=10&precio=17&stock=50&stockMinimo=10&stockMaximo=100&comentarios=x&activo=true

			} catch (Exception e) {
				out.println("error");
				System.out.println(e);
			}

		}
	}


	// <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
	/**
	 * Handles the HTTP <code>GET</code> method.
	 *
	 * @param request servlet request
	 * @param response servlet response
	 * @throws ServletException if a servlet-specific error occurs
	 * @throws IOException if an I/O error occurs
	 */
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * Handles the HTTP <code>POST</code> method.
	 *
	 * @param request servlet request
	 * @param response servlet response
	 * @throws ServletException if a servlet-specific error occurs
	 * @throws IOException if an I/O error occurs
	 */
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processRequest(request, response);
	}

	/**
	 * Returns a short description of the servlet.
	 *
	 * @return a String containing servlet description
	 */
	@Override
	public String getServletInfo() {
		return "Short description";
	}// </editor-fold>

}
