package articuloCliente;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

public class ArticuloCliente {

    public static void main(String[] args) throws Exception{
        // Cliente HTTP Clase
        String server="http://localhost:8080/server/web/articulos/v1";
        String url;
         /*  
        System.out.println("****************************************************");
        System.out.println("-- Google ");
        System.out.println("****************************************************");
        url="http://www.google.com.ar";
        System.out.println(responseBody(url));
        
     
        System.out.println("****************************************************");
        System.out.println("-- Servicio Meterologico Nacional ");
        System.out.println("****************************************************");
        url="https://ws.smn.gob.ar/map_items/weather";
        //url="https://ws.smn.gob.ar/";
        System.out.println(responseBody(url));
        */

        System.out.println("****************************************************");
        System.out.println("-- Server ");
        System.out.println("****************************************************");
        url=server;
        System.out.println(responseBody(url));
        
        System.out.println("****************************************************");
        System.out.println("-- ArticuloAlta 1");
        System.out.println("****************************************************");
        url=server+"/ArticuloAlta?nombre=Pelota&descripcion=pelota&tipo=JUGUETE&especieRecomendada=CANINO&costo=10&precio=17&stock=50&stockMinimo=10&stockMaximo=100&comentarios=x&activo=true";
        System.out.println(responseBody(url));
        
        System.out.println("****************************************************");
        System.out.println("-- ArticuloAlta 2");
        System.out.println("****************************************************");
        url=server+"/ArticuloAlta?nombre=Almuad�n&descripcion=pelota&tipo=JUGUETE&especieRecomendada=CANINO&costo=10&precio=17&stock=50&stockMinimo=10&stockMaximo=100&comentarios=x&activo=true";
        System.out.println(responseBody(url));
        
        System.out.println("****************************************************");
        System.out.println("-- ArticuloAlta 3");
        System.out.println("****************************************************");
        url=server+"/ArticuloAlta?nombre=Correa&descripcion=pelota&tipo=JUGUETE&especieRecomendada=CANINO&costo=10&precio=17&stock=50&stockMinimo=10&stockMaximo=100&comentarios=x&activo=true";
        System.out.println(responseBody(url));
        
        System.out.println("****************************************************");
        System.out.println("-- ArticuloAlta 4");
        System.out.println("****************************************************");
        url=server+"/ArticuloAlta?nombre=Peluche&descripcion=pelota&tipo=JUGUETE&especieRecomendada=CANINO&costo=10&precio=17&stock=50&stockMinimo=10&stockMaximo=100&comentarios=x&activo=true";
        System.out.println(responseBody(url));

        System.out.println("****************************************************");
        System.out.println("-- ArticulosAll ");
        System.out.println("****************************************************");
        url=server+"/ArticulosAll";
        System.out.println(responseBody(url));
        
        System.out.println("****************************************************");
        System.out.println("-- ArticuloLikeNombre ");
        System.out.println("****************************************************");
        url=server+"/LikeNombreArticulo?nombre=p";
        System.out.println(responseBody(url));
        
    }
    
    private static String responseBody(String url) throws InterruptedException, IOException {
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest
                .newBuilder()
                .uri(URI.create(url))
                .build();
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
        if(response.statusCode()==200){
            System.out.println("\033[32mstatus: "+response.statusCode());
        }else{
            System.out.println("\033[31mstatus: "+response.statusCode());
        }
        response.headers().map().forEach((k, v) -> System.out.println(k + " " + v));
        return response.body();
    }
}
