package ar.org.centro8.curso.java.web.entities.enums;

public enum TipoArticulo {
	PRENDA,
	JUGUETE,
	ALIMENTO,
	SNACK,
	ACCESORIO,
	CORREAS,
	MEDICAMENTO

}
