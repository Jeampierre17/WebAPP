package ar.org.centro8.curso.java.web.repositories.jpa;

import ar.org.centro8.curso.java.web.entities.Cliente;
import ar.org.centro8.curso.java.web.repositories.interfaces.I_ClienteRepository;
import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;

public class ClienteRepository implements I_ClienteRepository {
    private EntityManagerFactory emf;

    public ClienteRepository(EntityManagerFactory emf) {
        this.emf = emf;
    }

    @Override
    public void save(Cliente cliente) {
        if(cliente==null) return;
        EntityManager em=emf.createEntityManager();
        EntityTransaction tr = em.getTransaction();
        tr.begin();
        try {
            em.persist(cliente.getIdDireccion());
            em.persist(cliente);
            tr.commit();
        } catch (Exception e) {
            System.out.println(e);
            tr.rollback();
        }
        em.close();
    }

    @Override
    public void remove(Cliente cliente) {
        if(cliente==null) return;
        EntityManager em=emf.createEntityManager();        
        try {
            em.getTransaction().begin();
            em.remove(em.merge(cliente));
            em.flush();
            em.getTransaction().commit();
        } catch (Exception e) {
            System.out.println(e);
            em.getTransaction().rollback();
        }
        em.close(); 
    }

    @Override
    public void update(Cliente cliente) {
        if(cliente==null) return;
        EntityManager em=emf.createEntityManager();
        EntityTransaction tr = em.getTransaction();
        tr.begin();
        try {
            em.persist(cliente);
            tr.commit();
        } catch (Exception e) {
            System.out.println(e);
            tr.rollback();
        }
        em.close();    
    }

    @Override
    public List<Cliente> getAll() {
        EntityManager em=emf.createEntityManager();
        List<Cliente>list=(List<Cliente>)em.createNamedQuery("Cliente.findAll").getResultList();
        em.close();
        return list;
    }
    
}
