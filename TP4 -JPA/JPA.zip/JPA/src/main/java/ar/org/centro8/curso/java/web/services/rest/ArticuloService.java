package ar.org.centro8.curso.java.web.services.rest;

import ar.org.centro8.curso.java.web.entities.*;
import ar.org.centro8.curso.java.web.entities.enums.*;
import ar.org.centro8.curso.java.web.repositories.interfaces.*;
import ar.org.centro8.curso.java.web.repositories.jpa.ArticuloRepository;

import com.google.gson.Gson;

import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;


@Path("/articulos/v1")
public class ArticuloService {
	
    private EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPAPU");
    private I_ArticuloRepository ar=new ArticuloRepository(emf);
    
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String info(){
        return "Servicio articulo activo";
    }
    
    @GET
    @Path("/ArticulosAll")
    @Produces(MediaType.APPLICATION_JSON)
    public String getAll(){
        return new Gson().toJson(ar.getAll());
    }
    
    @GET
    @Path("/LikeNombreArticulo")
    @Produces(MediaType.APPLICATION_JSON)
    public String getLikeNombre(@QueryParam("nombre")String nombre){
        return new Gson().toJson(ar.getLikeNombre(nombre));
    }
    
    @GET
    @Path("/ArticuloAlta")
    @Produces(MediaType.TEXT_PLAIN)
    public String save(            
            @QueryParam("nombre")String name,
            @QueryParam("descripcion")String descripcion,
            @QueryParam("tipo")String tipo,
            @QueryParam("especieRecomendada")String especieRecomendada,
            @QueryParam("costo")double costo,
            @QueryParam("precio")double precio,
            @QueryParam("stock")int stock,
            @QueryParam("stockMinimo")int stockMinimo,
            @QueryParam("stockMaximo")int stockMaximo,
            @QueryParam("comentarios")String comentarios,
            @QueryParam("activo")boolean activo){
       
        Articulo articulo=new Articulo(
                name, 
                descripcion, 
                TipoArticulo.valueOf(tipo), 
                EspecieRecomendada.valueOf(especieRecomendada), 
                costo, 
                precio, 
                stock,
                stockMinimo,
                stockMaximo,
                comentarios,
                activo);
        ar.save(articulo);
        return articulo.getId()+"";
    }
    
    }
        