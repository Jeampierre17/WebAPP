package ar.org.centro8.curso.java.web.test;

import ar.org.centro8.curso.java.web.entities.Articulo;
import ar.org.centro8.curso.java.web.entities.Cliente;
import ar.org.centro8.curso.java.web.entities.Direccion;
import ar.org.centro8.curso.java.web.enums.EspecieRecomendada;
import ar.org.centro8.curso.java.web.enums.TipoArticulo;
import ar.org.centro8.curso.java.web.enums.TipoDocumento;
import java.time.LocalTime;
import java.util.Date;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class TestJPAConnector {

    public static void main(String[] args) {
        tiempo();
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPAPU");
        tiempo();
        EntityManager em = emf.createEntityManager();
        tiempo();

//        Query queryc1=em.createNamedQuery("Direccion.findById");
//        queryc1.setParameter("id", 1);
//        Direccion dir=(Direccion)queryc1.getSingleResult();
//        Cliente cliente=new Cliente("Juan", "Bautista", new Date(1980, 10, 10), TipoDocumento.CI.toString(), "98939393", "239939494", "nada@nada.com", "", dir);
//        Cliente cliente2=new Cliente("Ramiro", "Basualdo", new Date(1980, 10, 11), TipoDocumento.CI.toString(), "98939394", "239939494", "nada@nada.com", "", dir);
        Articulo articulo1 = new Articulo("Prueba JPA 1", "Prueba JPA 1", TipoArticulo.SNACK.toString(), EspecieRecomendada.ROEDOR.toString(), 100, 500, 10, 5, 15, "Prueba JPA 1");
        Articulo articulo2 = new Articulo("Prueba JPA 2", "Prueba JPA 2", TipoArticulo.SNACK.toString(), EspecieRecomendada.ROEDOR.toString(), 200, 600, 10, 5, 15, "Prueba JPA 2");

//        Query queryc2=em.createNamedQuery("Cliente.findById");
//        queryc2.setParameter("id", 4);
//        Cliente clientex=(Cliente)queryc2.getSingleResult();
        EntityTransaction tr = em.getTransaction();
        tr.begin();
        try {
//            em.persist(cliente);
//            em.persist(cliente2);
//            em.remove(clientex);
            em.persist(articulo1);
            em.persist(articulo2);
            tr.commit();
            System.out.println("Se guardo!");
        } catch (javax.persistence.PersistenceException e) {
            System.out.println("Error " + e.getLocalizedMessage());
            System.out.println("Error " + e.getMessage());
            tr.rollback();
        } catch (Exception e) {
            System.out.println(e);
            tr.rollback();
        }

        //em.createNamedQuery("Cliente.findAll").getResultList().forEach(System.out::println);
//        tiempo();
//        em.createNamedQuery("Direccion.findAll").getResultList().forEach(System.out::println);
//        Query queryc3=em.createNamedQuery("Cliente.findLikeApellido");
//        queryc3.setParameter("apellido", "%ba%");
//        queryc3.getResultList().forEach(System.out::println);
        Query querya1 = em.createNamedQuery("Articulo.findLikeNombre");
        querya1.setParameter("nombre", "%ba%");
        querya1.getResultList().forEach(System.out::println);

        tiempo();
        em.close();
        tiempo();
        emf.close();
        tiempo();
    }

    private static void tiempo() {
        System.out.println("******************************************");
        System.out.println(LocalTime.now());
        System.out.println("******************************************");
    }
}
