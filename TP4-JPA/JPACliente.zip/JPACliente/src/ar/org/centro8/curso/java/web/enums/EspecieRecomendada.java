package ar.org.centro8.curso.java.web.enums;

public enum EspecieRecomendada {
    CANINO,
    FELINO,
    AVE,
    PEZ,
    ROEDOR    
}
